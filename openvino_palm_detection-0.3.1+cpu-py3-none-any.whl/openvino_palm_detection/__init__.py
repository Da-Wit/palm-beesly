__version__ = "0.3.1"
from openvino_palm_detection.model import InferenceModel
